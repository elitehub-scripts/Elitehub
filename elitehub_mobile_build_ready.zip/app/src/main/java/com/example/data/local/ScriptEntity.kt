package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ScriptDto

@Entity(tableName = "cached_scripts")
data class ScriptEntity(
    @PrimaryKey val name: String,
    val language: String,
    val updatedAt: String?,
    val bytes: Long,
    val rawUrl: String?,
    val fallbackUrl: String?,
    val ownerProfile: String?,
    val owned: Boolean,
    val cachedSource: String? = null,
    val cachedAt: Long = System.currentTimeMillis()
) {
    fun toDto(): ScriptDto {
        return ScriptDto(
            name = name,
            language = language,
            updatedAt = updatedAt,
            bytes = bytes,
            rawUrl = rawUrl,
            fallbackUrl = fallbackUrl,
            ownerProfile = ownerProfile,
            owned = owned
        )
    }

    companion object {
        fun fromDto(dto: ScriptDto, source: String? = null): ScriptEntity {
            return ScriptEntity(
                name = dto.name,
                language = dto.language,
                updatedAt = dto.updatedAt,
                bytes = dto.bytes,
                rawUrl = dto.rawUrl,
                fallbackUrl = dto.fallbackUrl,
                ownerProfile = dto.ownerProfile,
                owned = dto.owned,
                cachedSource = source,
                cachedAt = System.currentTimeMillis()
            )
        }
    }
}
