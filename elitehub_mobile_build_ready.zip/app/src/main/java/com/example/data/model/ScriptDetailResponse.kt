package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ScriptDetailResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "name") val name: String? = null,
    @Json(name = "language") val language: String? = null,
    @Json(name = "source") val source: String? = null,
    @Json(name = "bytes") val bytes: Long? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "owner_profile") val ownerProfile: String? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)
