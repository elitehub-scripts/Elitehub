package com.example.data.model

data class DiagnosticResult(
    val baseUrl: String,
    val isHttps: Boolean,
    val isReachable: Boolean,
    val isAppKeyAccepted: Boolean,
    val isListResponding: Boolean,
    val isJsonValid: Boolean,
    val scriptsCount: Int = 0,
    val statusCode: Int = 0,
    val statusSummary: DiagnosticStatus,
    val detailMessage: String
)

enum class DiagnosticStatus {
    CONNECTED,
    UNAUTHORIZED_APP_KEY,
    SERVER_UNAVAILABLE,
    INVALID_RESPONSE,
    CONFIG_ERROR
}
