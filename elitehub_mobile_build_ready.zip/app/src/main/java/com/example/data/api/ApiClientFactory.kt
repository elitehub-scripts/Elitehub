package com.example.data.api

import com.example.data.config.EliteHubConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class ApiClientFactory(
    private val keyProvider: () -> String,
    private val baseUrlProvider: () -> String
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private var currentBaseUrl: String? = null
    private var cachedService: EliteHubApiService? = null

    @Synchronized
    fun getApiService(): EliteHubApiService {
        val targetBaseUrl = EliteHubConfig.sanitizeBaseUrl(baseUrlProvider())
        if (cachedService != null && currentBaseUrl == targetBaseUrl) {
            return cachedService!!
        }

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .addInterceptor(EliteHubAppKeyInterceptor(keyProvider))
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(targetBaseUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        val service = retrofit.create(EliteHubApiService::class.java)
        cachedService = service
        currentBaseUrl = targetBaseUrl
        return service
    }

    @Synchronized
    fun invalidate() {
        cachedService = null
        currentBaseUrl = null
    }
}
