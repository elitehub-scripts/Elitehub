package com.example.data.api

import com.example.data.config.EliteHubConfig
import okhttp3.Interceptor
import okhttp3.Response

class EliteHubAppKeyInterceptor(
    private val keyProvider: () -> String
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val key = keyProvider().trim()

        val requestBuilder = originalRequest.newBuilder()
        if (key.isNotEmpty()) {
            requestBuilder.header(EliteHubConfig.HEADER_APP_KEY, key)
        }
        requestBuilder.header("Accept", "application/json")

        return chain.proceed(requestBuilder.build())
    }
}
