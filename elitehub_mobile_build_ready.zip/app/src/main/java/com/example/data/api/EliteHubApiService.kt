package com.example.data.api

import com.example.data.model.ApiResponse
import com.example.data.model.ScriptDetailResponse
import com.example.data.model.ScriptListResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

interface EliteHubApiService {

    @GET("app-api.php")
    suspend fun listScripts(
        @Query("action") action: String = "list",
        @Query("email") email: String? = null
    ): Response<ScriptListResponse>

    @GET("app-api.php")
    suspend fun getOwnerScript(
        @Query("action") action: String = "get",
        @Query("name") name: String,
        @Query("email") email: String
    ): Response<ScriptDetailResponse>

    @FormUrlEncoded
    @POST("app-api.php")
    suspend fun publishScript(
        @Field("action") action: String = "publish",
        @Field("name") name: String,
        @Field("language") language: String,
        @Field("source") source: String,
        @Field("email") email: String,
        @Field("profile") profile: String
    ): Response<ApiResponse>

    @FormUrlEncoded
    @POST("app-api.php")
    suspend fun saveScript(
        @Field("action") action: String = "save",
        @Field("name") name: String,
        @Field("original_name") originalName: String,
        @Field("language") language: String,
        @Field("source") source: String,
        @Field("email") email: String
    ): Response<ApiResponse>

    @FormUrlEncoded
    @POST("app-api.php")
    suspend fun deleteScript(
        @Field("action") action: String = "delete",
        @Field("name") name: String,
        @Field("email") email: String
    ): Response<ApiResponse>

    @GET("raw.php")
    suspend fun getRawScript(
        @Query("name") name: String
    ): Response<ResponseBody>

    @GET
    suspend fun fetchUrlDirect(
        @Url fullUrl: String
    ): Response<ResponseBody>
}
