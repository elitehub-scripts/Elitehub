package com.example.data.config

import com.example.BuildConfig

object EliteHubConfig {
    const val LOCKED_BASE_URL: String = "https://elitehub.unaux.com/"
    const val LOCKED_APP_KEY: String = "NILKxgj_us22aBOUb3Ahd-kUldNgE0VOdOGwDTtyFor2aI"

    val DEFAULT_BASE_URL: String = LOCKED_BASE_URL
    val DEFAULT_APP_KEY: String = LOCKED_APP_KEY

    const val APP_API_PATH = "app-api.php"
    const val RAW_PATH = "raw.php"
    const val HEADER_APP_KEY = "X-EliteHub-App-Key"

    val ALLOWED_LANGUAGES = listOf("lua", "els", "txt", "js", "json", "py")
    const val MAX_SOURCE_BYTES = 1048576L // 1 MiB

    private val PROFILE_REGEX = Regex("^[A-Za-z0-9 ._\\-]{1,40}$")
    private val SCRIPT_NAME_REGEX = Regex("^[A-Za-z0-9._\\-]{1,60}$")

    fun isValidProfileName(name: String): Boolean {
        return name.isNotBlank() && name.length <= 40 && PROFILE_REGEX.matches(name)
    }

    fun isValidScriptName(name: String): Boolean {
        return name.isNotBlank() && name.length <= 60 && SCRIPT_NAME_REGEX.matches(name)
    }

    fun isAllowedLanguage(lang: String): Boolean {
        return ALLOWED_LANGUAGES.contains(lang.lowercase().trim())
    }

    fun normalizeEmail(email: String): String {
        return email.trim().lowercase()
    }

    fun sanitizeBaseUrl(url: String): String {
        var trimmed = url.trim()
        if (!trimmed.endsWith("/")) {
            trimmed = "$trimmed/"
        }
        return trimmed
    }
}
