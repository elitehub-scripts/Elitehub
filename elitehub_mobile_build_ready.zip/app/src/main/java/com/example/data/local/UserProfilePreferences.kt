package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.config.EliteHubConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "elitehub_user_prefs")

class UserProfilePreferences(private val context: Context) {

    companion object {
        val KEY_PROFILE_NAME = stringPreferencesKey("profile_name")
        val KEY_EMAIL = stringPreferencesKey("email")
        val KEY_CUSTOM_BASE_URL = stringPreferencesKey("custom_base_url")
        val KEY_CUSTOM_APP_KEY = stringPreferencesKey("custom_app_key")
        val KEY_FAVORITES = stringSetPreferencesKey("favorites")
        val KEY_HISTORY = stringPreferencesKey("history_json")
        val KEY_THEME = stringPreferencesKey("theme_mode")
        val KEY_EDITOR_FONT_SIZE = intPreferencesKey("editor_font_size")
    }

    val profileNameFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_PROFILE_NAME] ?: ""
    }

    val emailFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_EMAIL] ?: ""
    }

    val customBaseUrlFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CUSTOM_BASE_URL] ?: ""
    }

    val customAppKeyFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CUSTOM_APP_KEY] ?: ""
    }

    val activeBaseUrlFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CUSTOM_BASE_URL]?.takeIf { it.isNotBlank() }
            ?: EliteHubConfig.DEFAULT_BASE_URL
    }

    val activeAppKeyFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CUSTOM_APP_KEY]?.takeIf { it.isNotBlank() }
            ?: EliteHubConfig.DEFAULT_APP_KEY
    }

    val favoritesFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[KEY_FAVORITES] ?: emptySet()
    }

    val historyFlow: Flow<List<String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[KEY_HISTORY] ?: ""
        if (raw.isBlank()) emptyList()
        else raw.split(",;,;").filter { it.isNotBlank() }
    }

    val themeModeFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_THEME] ?: "system"
    }

    val editorFontSizeFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_EDITOR_FONT_SIZE] ?: 13
    }

    suspend fun saveProfile(name: String, email: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_PROFILE_NAME] = name.trim()
            prefs[KEY_EMAIL] = EliteHubConfig.normalizeEmail(email)
        }
    }

    suspend fun saveCustomBaseUrl(url: String) {
        context.dataStore.edit { prefs ->
            if (url.isBlank()) {
                prefs.remove(KEY_CUSTOM_BASE_URL)
            } else {
                prefs[KEY_CUSTOM_BASE_URL] = EliteHubConfig.sanitizeBaseUrl(url)
            }
        }
    }

    suspend fun saveCustomAppKey(key: String) {
        context.dataStore.edit { prefs ->
            if (key.isBlank()) {
                prefs.remove(KEY_CUSTOM_APP_KEY)
            } else {
                prefs[KEY_CUSTOM_APP_KEY] = key.trim()
            }
        }
    }

    suspend fun toggleFavorite(scriptName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_FAVORITES]?.toMutableSet() ?: mutableSetOf()
            if (current.contains(scriptName)) {
                current.remove(scriptName)
            } else {
                current.add(scriptName)
            }
            prefs[KEY_FAVORITES] = current
        }
    }

    suspend fun recordHistory(scriptName: String) {
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_HISTORY] ?: ""
            val list = if (raw.isBlank()) mutableListOf() else raw.split(",;,;").toMutableList()
            list.remove(scriptName)
            list.add(0, scriptName)
            val trimmed = list.take(30)
            prefs[KEY_HISTORY] = trimmed.joinToString(",;,;")
        }
    }

    suspend fun clearHistory() {
        context.dataStore.edit { prefs ->
            prefs.remove(KEY_HISTORY)
        }
    }

    suspend fun setThemeMode(theme: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_THEME] = theme
        }
    }

    suspend fun setEditorFontSize(size: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_EDITOR_FONT_SIZE] = size.coerceIn(10, 22)
        }
    }
}
