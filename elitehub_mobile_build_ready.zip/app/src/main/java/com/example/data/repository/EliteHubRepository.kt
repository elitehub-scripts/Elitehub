package com.example.data.repository

import android.content.Context
import com.example.data.api.ApiClientFactory
import com.example.data.config.EliteHubConfig
import com.example.data.local.AppDatabase
import com.example.data.local.ScriptEntity
import com.example.data.local.UserProfilePreferences
import com.example.data.model.ApiResponse
import com.example.data.model.DiagnosticResult
import com.example.data.model.DiagnosticStatus
import com.example.data.model.ScriptDto
import com.example.data.model.ScriptListResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

sealed class RepoResult<out T> {
    data class Success<T>(val data: T, val isFromCache: Boolean = false) : RepoResult<T>()
    data class Error(val message: String, val code: String? = null, val cachedData: Any? = null) : RepoResult<Nothing>()
}

class EliteHubRepository(
    private val context: Context,
    val userPrefs: UserProfilePreferences
) {
    private val database = AppDatabase.getDatabase(context)
    private val scriptDao = database.scriptDao()

    private var activeBaseUrl: String = EliteHubConfig.DEFAULT_BASE_URL
    private var activeAppKey: String = EliteHubConfig.DEFAULT_APP_KEY

    private val apiFactory = ApiClientFactory(
        keyProvider = { activeAppKey },
        baseUrlProvider = { activeBaseUrl }
    )

    suspend fun updateRuntimeConfig(baseUrl: String, appKey: String) {
        activeBaseUrl = EliteHubConfig.sanitizeBaseUrl(
            baseUrl.trim().ifBlank { EliteHubConfig.DEFAULT_BASE_URL }
        )
        activeAppKey = appKey.trim().ifBlank { EliteHubConfig.DEFAULT_APP_KEY }
        apiFactory.invalidate()
    }

    suspend fun initConfig() {
        activeBaseUrl = userPrefs.activeBaseUrlFlow.first()
        activeAppKey = userPrefs.activeAppKeyFlow.first()
        apiFactory.invalidate()
    }

    fun getCachedScriptsFlow(): Flow<List<ScriptDto>> {
        return scriptDao.getAllScripts().map { list ->
            list.map { it.toDto() }
        }
    }

    suspend fun fetchScripts(userEmail: String? = null): RepoResult<List<ScriptDto>> = withContext(Dispatchers.IO) {
        initConfig()
        try {
            val emailParam = userEmail?.trim()?.takeIf { it.isNotEmpty() }
            val response = apiFactory.getApiService().listScripts(action = "list", email = emailParam)

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null && body.ok) {
                    val remoteList = body.scripts ?: emptyList()
                    val entities = remoteList.map { ScriptEntity.fromDto(it) }
                    scriptDao.clearAll()
                    scriptDao.insertAll(entities)
                    return@withContext RepoResult.Success(remoteList, isFromCache = false)
                } else {
                    val errorMsg = mapBackendError(body?.error ?: body?.message, response.code())
                    return@withContext RepoResult.Error(errorMsg, body?.error)
                }
            } else {
                val errorBody = response.errorBody()?.string()
                val parsedCode = parseErrorJson(errorBody)
                val mapped = mapBackendError(parsedCode, response.code())
                // Check if we have cached scripts
                val cached = scriptDao.getAllScripts().first().map { it.toDto() }
                if (cached.isNotEmpty()) {
                    return@withContext RepoResult.Success(cached, isFromCache = true)
                }
                return@withContext RepoResult.Error(mapped, parsedCode)
            }
        } catch (e: Exception) {
            val cached = scriptDao.getAllScripts().first().map { it.toDto() }
            if (cached.isNotEmpty()) {
                return@withContext RepoResult.Success(cached, isFromCache = true)
            }
            return@withContext RepoResult.Error(mapNetworkException(e))
        }
    }

    suspend fun getScriptSource(script: ScriptDto, userEmail: String): RepoResult<String> = withContext(Dispatchers.IO) {
        initConfig()
        val normalizedEmail = EliteHubConfig.normalizeEmail(userEmail)

        // 1. If email is provided, try owner endpoint first
        if (normalizedEmail.isNotBlank()) {
            try {
                val ownerRes = apiFactory.getApiService().getOwnerScript(
                    action = "get",
                    name = script.name,
                    email = normalizedEmail
                )
                if (ownerRes.isSuccessful) {
                    val body = ownerRes.body()
                    if (body != null && body.ok && body.source != null) {
                        scriptDao.insert(ScriptEntity.fromDto(script, body.source))
                        return@withContext RepoResult.Success(body.source, isFromCache = false)
                    }
                }
            } catch (_: Exception) {
                // Fall through to public raw fetch
            }
        }

        // 2. Fall back to public raw endpoint
        try {
            val rawRes = if (!script.rawUrl.isNullOrBlank()) {
                apiFactory.getApiService().fetchUrlDirect(script.rawUrl)
            } else {
                apiFactory.getApiService().getRawScript(script.name)
            }

            if (rawRes.isSuccessful) {
                val source = rawRes.body()?.string() ?: ""
                scriptDao.insert(ScriptEntity.fromDto(script, source))
                return@withContext RepoResult.Success(source, isFromCache = false)
            }
        } catch (e: Exception) {
            // Check cache
            val cached = scriptDao.getScript(script.name)
            if (cached?.cachedSource != null) {
                return@withContext RepoResult.Success(cached.cachedSource, isFromCache = true)
            }
            return@withContext RepoResult.Error(mapNetworkException(e))
        }

        // 3. Fallback to cache if available
        val cached = scriptDao.getScript(script.name)
        if (cached?.cachedSource != null) {
            return@withContext RepoResult.Success(cached.cachedSource, isFromCache = true)
        }
        return@withContext RepoResult.Error("Unable to load script source from server or cache.")
    }

    suspend fun publishScript(
        name: String,
        language: String,
        source: String,
        email: String,
        profile: String
    ): RepoResult<String> = withContext(Dispatchers.IO) {
        initConfig()
        // Client-side validations
        if (!EliteHubConfig.isValidScriptName(name)) {
            return@withContext RepoResult.Error("Invalid script name. Use 1-60 alphanumeric characters, dots, underscores, or hyphens.")
        }
        if (!EliteHubConfig.isAllowedLanguage(language)) {
            return@withContext RepoResult.Error("Language '$language' is not supported. Allowed: ${EliteHubConfig.ALLOWED_LANGUAGES.joinToString()}")
        }
        if (!EliteHubConfig.isValidProfileName(profile)) {
            return@withContext RepoResult.Error("Invalid creator profile name. Must be 1-40 alphanumeric characters, spaces, dots, underscores, or hyphens.")
        }
        val normalizedEmail = EliteHubConfig.normalizeEmail(email)
        if (normalizedEmail.isBlank() || !normalizedEmail.contains("@")) {
            return@withContext RepoResult.Error("A valid email address is required for script ownership.")
        }
        val sourceBytes = source.toByteArray(Charsets.UTF_8).size
        if (sourceBytes > EliteHubConfig.MAX_SOURCE_BYTES) {
            return@withContext RepoResult.Error("Script size (${sourceBytes / 1024} KB) exceeds the 1 MiB limit.")
        }
        if (source.isBlank()) {
            return@withContext RepoResult.Error("Script source cannot be empty.")
        }

        try {
            val response = apiFactory.getApiService().publishScript(
                action = "publish",
                name = name.trim(),
                language = language.trim().lowercase(),
                source = source,
                email = normalizedEmail,
                profile = profile.trim()
            )

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null && body.ok) {
                    fetchScripts(normalizedEmail)
                    return@withContext RepoResult.Success(body.message ?: "Script published successfully!")
                } else {
                    val code = body?.error ?: body?.message
                    return@withContext RepoResult.Error(mapBackendError(code, response.code()))
                }
            } else {
                val parsedCode = parseErrorJson(response.errorBody()?.string())
                return@withContext RepoResult.Error(mapBackendError(parsedCode, response.code()))
            }
        } catch (e: Exception) {
            return@withContext RepoResult.Error(mapNetworkException(e))
        }
    }

    suspend fun saveScript(
        name: String,
        originalName: String,
        language: String,
        source: String,
        email: String
    ): RepoResult<String> = withContext(Dispatchers.IO) {
        initConfig()
        if (!EliteHubConfig.isValidScriptName(name)) {
            return@withContext RepoResult.Error("Invalid script name.")
        }
        if (!EliteHubConfig.isAllowedLanguage(language)) {
            return@withContext RepoResult.Error("Language '$language' is not supported.")
        }
        val normalizedEmail = EliteHubConfig.normalizeEmail(email)
        if (normalizedEmail.isBlank()) {
            return@withContext RepoResult.Error("Owner email is required to save changes.")
        }
        val sourceBytes = source.toByteArray(Charsets.UTF_8).size
        if (sourceBytes > EliteHubConfig.MAX_SOURCE_BYTES) {
            return@withContext RepoResult.Error("Script size exceeds 1 MiB limit.")
        }

        try {
            val response = apiFactory.getApiService().saveScript(
                action = "save",
                name = name.trim(),
                originalName = originalName.trim(),
                language = language.trim().lowercase(),
                source = source,
                email = normalizedEmail
            )

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null && body.ok) {
                    fetchScripts(normalizedEmail)
                    return@withContext RepoResult.Success(body.message ?: "Script updated successfully!")
                } else {
                    val code = body?.error ?: body?.message
                    return@withContext RepoResult.Error(mapBackendError(code, response.code()))
                }
            } else {
                val parsedCode = parseErrorJson(response.errorBody()?.string())
                return@withContext RepoResult.Error(mapBackendError(parsedCode, response.code()))
            }
        } catch (e: Exception) {
            return@withContext RepoResult.Error(mapNetworkException(e))
        }
    }

    suspend fun deleteScript(name: String, email: String): RepoResult<String> = withContext(Dispatchers.IO) {
        initConfig()
        val normalizedEmail = EliteHubConfig.normalizeEmail(email)
        if (normalizedEmail.isBlank()) {
            return@withContext RepoResult.Error("Owner email is required to delete script.")
        }

        try {
            val response = apiFactory.getApiService().deleteScript(
                action = "delete",
                name = name.trim(),
                email = normalizedEmail
            )

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null && body.ok) {
                    scriptDao.deleteByName(name)
                    fetchScripts(normalizedEmail)
                    return@withContext RepoResult.Success(body.message ?: "Script deleted successfully.")
                } else {
                    val code = body?.error ?: body?.message
                    return@withContext RepoResult.Error(mapBackendError(code, response.code()))
                }
            } else {
                val parsedCode = parseErrorJson(response.errorBody()?.string())
                return@withContext RepoResult.Error(mapBackendError(parsedCode, response.code()))
            }
        } catch (e: Exception) {
            return@withContext RepoResult.Error(mapNetworkException(e))
        }
    }

    suspend fun runDiagnostics(testBaseUrl: String, testAppKey: String): DiagnosticResult = withContext(Dispatchers.IO) {
        val sanitizedUrl = EliteHubConfig.sanitizeBaseUrl(testBaseUrl)
        val isHttps = sanitizedUrl.startsWith("https://", ignoreCase = true)

        if (!sanitizedUrl.startsWith("http://") && !sanitizedUrl.startsWith("https://")) {
            return@withContext DiagnosticResult(
                baseUrl = sanitizedUrl,
                isHttps = false,
                isReachable = false,
                isAppKeyAccepted = false,
                isListResponding = false,
                isJsonValid = false,
                statusCode = 0,
                statusSummary = DiagnosticStatus.CONFIG_ERROR,
                detailMessage = "Base URL must begin with https:// (or http:// for local dev)."
            )
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        val targetUrl = "${sanitizedUrl}${EliteHubConfig.APP_API_PATH}?action=list"

        try {
            val requestBuilder = Request.Builder().url(targetUrl)
            if (testAppKey.isNotBlank()) {
                requestBuilder.header(EliteHubConfig.HEADER_APP_KEY, testAppKey.trim())
            }
            requestBuilder.header("Accept", "application/json")

            val response = client.newCall(requestBuilder.build()).execute()
            val code = response.code
            val bodyString = response.body?.string().orEmpty()

            if (code == 401 || code == 403 || bodyString.contains("APP_KEY_REQUIRED", ignoreCase = true)) {
                return@withContext DiagnosticResult(
                    baseUrl = sanitizedUrl,
                    isHttps = isHttps,
                    isReachable = true,
                    isAppKeyAccepted = false,
                    isListResponding = false,
                    isJsonValid = false,
                    statusCode = code,
                    statusSummary = DiagnosticStatus.UNAUTHORIZED_APP_KEY,
                    detailMessage = "App key was rejected or missing. Check X-EliteHub-App-Key header in config.php."
                )
            }

            if (!response.isSuccessful) {
                return@withContext DiagnosticResult(
                    baseUrl = sanitizedUrl,
                    isHttps = isHttps,
                    isReachable = true,
                    isAppKeyAccepted = true,
                    isListResponding = false,
                    isJsonValid = false,
                    statusCode = code,
                    statusSummary = DiagnosticStatus.SERVER_UNAVAILABLE,
                    detailMessage = "Server returned HTTP $code when accessing app-api.php."
                )
            }

            // Check JSON validity
            try {
                val json = JSONObject(bodyString)
                val ok = json.optBoolean("ok", false)
                val scriptsArr = json.optJSONArray("scripts")
                val count = scriptsArr?.length() ?: 0

                return@withContext DiagnosticResult(
                    baseUrl = sanitizedUrl,
                    isHttps = isHttps,
                    isReachable = true,
                    isAppKeyAccepted = true,
                    isListResponding = ok,
                    isJsonValid = true,
                    scriptsCount = count,
                    statusCode = code,
                    statusSummary = DiagnosticStatus.CONNECTED,
                    detailMessage = "Connection verified! Backend responded with $count scripts."
                )
            } catch (_: Exception) {
                return@withContext DiagnosticResult(
                    baseUrl = sanitizedUrl,
                    isHttps = isHttps,
                    isReachable = true,
                    isAppKeyAccepted = true,
                    isListResponding = false,
                    isJsonValid = false,
                    statusCode = code,
                    statusSummary = DiagnosticStatus.INVALID_RESPONSE,
                    detailMessage = "Response received was not valid EliteHub JSON format."
                )
            }

        } catch (e: Exception) {
            val summary = when (e) {
                is UnknownHostException -> "DNS failure: could not resolve host."
                is ConnectException -> "Connection refused: server is not reachable."
                is SocketTimeoutException -> "Request timed out: server took too long to respond."
                else -> e.localizedMessage ?: "Network error."
            }
            return@withContext DiagnosticResult(
                baseUrl = sanitizedUrl,
                isHttps = isHttps,
                isReachable = false,
                isAppKeyAccepted = false,
                isListResponding = false,
                isJsonValid = false,
                statusCode = 0,
                statusSummary = DiagnosticStatus.SERVER_UNAVAILABLE,
                detailMessage = summary
            )
        }
    }

    private fun mapBackendError(error: String?, httpStatus: Int = 0): String {
        return when {
            error?.contains("APP_KEY_REQUIRED", ignoreCase = true) == true || httpStatus == 401 ->
                "App connection configuration is invalid. Verify X-EliteHub-App-Key header."
            error?.contains("OWNER_REQUIRED", ignoreCase = true) == true || httpStatus == 403 ->
                "You are not recognized as the owner of this script. The provided email does not match."
            error?.contains("NAME_CONFLICT", ignoreCase = true) == true || httpStatus == 409 ->
                "Script name or profile already in use. Please select a different name."
            error?.contains("PAYLOAD_TOO_LARGE", ignoreCase = true) == true || httpStatus == 413 ->
                "Script source exceeds the 1 MiB limit."
            error?.contains("INVALID_INPUT", ignoreCase = true) == true || httpStatus == 422 ->
                "Invalid form data. Please check script name, allowed language, and creator profile."
            httpStatus == 404 ->
                "Script was not found on the server."
            httpStatus >= 500 ->
                "Server storage or backend error. Please try again later."
            !error.isNullOrBlank() ->
                error
            else ->
                "Operation failed with HTTP status $httpStatus."
        }
    }

    private fun parseErrorJson(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        return try {
            val json = JSONObject(raw)
            json.optString("error").takeIf { it.isNotEmpty() }
                ?: json.optString("message").takeIf { it.isNotEmpty() }
        } catch (_: Exception) {
            null
        }
    }

    private fun mapNetworkException(e: Exception): String {
        return when (e) {
            is UnknownHostException -> "Cannot connect to server. Check your internet connection or server domain."
            is SocketTimeoutException -> "Connection timed out. Server is taking too long to respond."
            is ConnectException -> "Server connection refused. Verify that the backend is online."
            is IOException -> "Network error: ${e.message ?: "Unable to complete request"}"
            else -> "Unexpected error: ${e.localizedMessage ?: "Unknown"}"
        }
    }
}
