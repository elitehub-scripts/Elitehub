package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScriptDao {
    @Query("SELECT * FROM cached_scripts ORDER BY cachedAt DESC")
    fun getAllScripts(): Flow<List<ScriptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(scripts: List<ScriptEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(script: ScriptEntity)

    @Query("SELECT * FROM cached_scripts WHERE name = :name LIMIT 1")
    suspend fun getScript(name: String): ScriptEntity?

    @Query("SELECT * FROM cached_scripts WHERE name = :name LIMIT 1")
    fun getScriptFlow(name: String): Flow<ScriptEntity?>

    @Query("DELETE FROM cached_scripts WHERE name = :name")
    suspend fun deleteByName(name: String)

    @Query("DELETE FROM cached_scripts")
    suspend fun clearAll()
}
