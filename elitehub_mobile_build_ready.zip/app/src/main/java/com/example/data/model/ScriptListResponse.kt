package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ScriptListResponse(
    @Json(name = "ok") val ok: Boolean = false,
    @Json(name = "scripts") val scripts: List<ScriptDto>? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)
