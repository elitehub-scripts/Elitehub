package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ScriptDto(
    @Json(name = "name") val name: String,
    @Json(name = "language") val language: String = "txt",
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "bytes") val bytes: Long = 0,
    @Json(name = "raw_url") val rawUrl: String? = null,
    @Json(name = "fallback_url") val fallbackUrl: String? = null,
    @Json(name = "owner_profile") val ownerProfile: String? = null,
    @Json(name = "owned") val owned: Boolean = false
) {
    fun getFormattedSize(): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> String.format("%.1f KB", bytes / 1024.0)
            else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
        }
    }
}
