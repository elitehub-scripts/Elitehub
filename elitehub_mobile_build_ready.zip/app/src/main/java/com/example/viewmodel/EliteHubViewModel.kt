package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserProfilePreferences
import com.example.data.model.DiagnosticResult
import com.example.data.model.ScriptDto
import com.example.data.repository.EliteHubRepository
import com.example.data.repository.RepoResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SortOption {
    NEWEST,
    NAME_ASC,
    SIZE_DESC
}

class EliteHubViewModel(application: Application) : AndroidViewModel(application) {

    val userPrefs = UserProfilePreferences(application)
    val repository = EliteHubRepository(application, userPrefs)

    private val _rawScripts = MutableStateFlow<List<ScriptDto>>(emptyList())
    val rawScripts: StateFlow<List<ScriptDto>> = _rawScripts.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedLanguageFilter = MutableStateFlow<String?>(null)
    val selectedLanguageFilter: StateFlow<String?> = _selectedLanguageFilter.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.NEWEST)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    val profileName: StateFlow<String> = userPrefs.profileNameFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val userEmail: StateFlow<String> = userPrefs.emailFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val customBaseUrl: StateFlow<String> = userPrefs.customBaseUrlFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val customAppKey: StateFlow<String> = userPrefs.customAppKeyFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val activeBaseUrl: StateFlow<String> = userPrefs.activeBaseUrlFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )
 
    val activeAppKey: StateFlow<String> = userPrefs.activeAppKeyFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val favorites: StateFlow<Set<String>> = userPrefs.favoritesFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet()
    )

    val history: StateFlow<List<String>> = userPrefs.historyFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val themeMode: StateFlow<String> = userPrefs.themeModeFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), "system"
    )

    val editorFontSize: StateFlow<Int> = userPrefs.editorFontSizeFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), 13
    )

    private val _diagnosticResult = MutableStateFlow<DiagnosticResult?>(null)
    val diagnosticResult: StateFlow<DiagnosticResult?> = _diagnosticResult.asStateFlow()

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    // Filtered & Sorted scripts
    val filteredScripts: StateFlow<List<ScriptDto>> = combine(
        _rawScripts,
        _searchQuery,
        _selectedLanguageFilter,
        _sortOption
    ) { scripts, query, lang, sort ->
        var result = scripts

        if (!lang.isNullOrBlank()) {
            result = result.filter { it.language.equals(lang, ignoreCase = true) }
        }

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            result = result.filter {
                it.name.lowercase().contains(q) ||
                it.language.lowercase().contains(q) ||
                (it.ownerProfile?.lowercase()?.contains(q) == true)
            }
        }

        when (sort) {
            SortOption.NEWEST -> result.sortedByDescending { it.updatedAt ?: "" }
            SortOption.NAME_ASC -> result.sortedBy { it.name.lowercase() }
            SortOption.SIZE_DESC -> result.sortedByDescending { it.bytes }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Owned scripts
    val myScripts: StateFlow<List<ScriptDto>> = combine(
        _rawScripts,
        profileName,
        userEmail
    ) { scripts, profile, email ->
        scripts.filter {
            it.owned || (profile.isNotBlank() && it.ownerProfile?.equals(profile, ignoreCase = true) == true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Observe local cached scripts from Room
        viewModelScope.launch {
            repository.getCachedScriptsFlow().collect { cached ->
                if (_rawScripts.value.isEmpty() && cached.isNotEmpty()) {
                    _rawScripts.value = cached
                }
            }
        }
        refreshScripts()
    }

    fun refreshScripts() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _errorMessage.value = null
            val result = repository.fetchScripts(userEmail.value)
            when (result) {
                is RepoResult.Success -> {
                    _rawScripts.value = result.data
                    _isOffline.value = result.isFromCache
                }
                is RepoResult.Error -> {
                    _errorMessage.value = result.message
                }
            }
            _isRefreshing.value = false
            _isLoading.value = false
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setLanguageFilter(language: String?) {
        _selectedLanguageFilter.value = language
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    fun loadScriptSource(script: ScriptDto, onResult: (String?, Boolean) -> Unit) {
        viewModelScope.launch {
            recordHistory(script.name)
            val result = repository.getScriptSource(script, userEmail.value)
            when (result) {
                is RepoResult.Success -> onResult(result.data, result.isFromCache)
                is RepoResult.Error -> onResult(null, false)
            }
        }
    }

    fun publishScript(
        name: String,
        language: String,
        source: String,
        email: String,
        profile: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.publishScript(name, language, source, email, profile)
            _isLoading.value = false
            when (result) {
                is RepoResult.Success -> {
                    refreshScripts()
                    onComplete(true, result.data)
                }
                is RepoResult.Error -> {
                    onComplete(false, result.message)
                }
            }
        }
    }

    fun saveScript(
        name: String,
        originalName: String,
        language: String,
        source: String,
        email: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.saveScript(name, originalName, language, source, email)
            _isLoading.value = false
            when (result) {
                is RepoResult.Success -> {
                    refreshScripts()
                    onComplete(true, result.data)
                }
                is RepoResult.Error -> {
                    onComplete(false, result.message)
                }
            }
        }
    }

    fun deleteScript(
        name: String,
        email: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.deleteScript(name, email)
            _isLoading.value = false
            when (result) {
                is RepoResult.Success -> {
                    refreshScripts()
                    onComplete(true, result.data)
                }
                is RepoResult.Error -> {
                    onComplete(false, result.message)
                }
            }
        }
    }

    fun saveProfile(name: String, email: String) {
        viewModelScope.launch {
            userPrefs.saveProfile(name, email)
            refreshScripts()
        }
    }

    fun saveBaseUrl(url: String) {
        viewModelScope.launch {
            userPrefs.saveCustomBaseUrl(url)
            repository.updateRuntimeConfig(url, customAppKey.value)
            refreshScripts()
        }
    }

    fun saveAppKey(key: String) {
        viewModelScope.launch {
            userPrefs.saveCustomAppKey(key)
            repository.updateRuntimeConfig(activeBaseUrl.value, key)
            refreshScripts()
        }
    }

    fun toggleFavorite(scriptName: String) {
        viewModelScope.launch {
            userPrefs.toggleFavorite(scriptName)
        }
    }

    fun recordHistory(scriptName: String) {
        viewModelScope.launch {
            userPrefs.recordHistory(scriptName)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            userPrefs.clearHistory()
        }
    }

    fun setThemeMode(theme: String) {
        viewModelScope.launch {
            userPrefs.setThemeMode(theme)
        }
    }

    fun setEditorFontSize(size: Int) {
        viewModelScope.launch {
            userPrefs.setEditorFontSize(size)
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun testConnection(testUrl: String, testKey: String) {
        viewModelScope.launch {
            _isTestingConnection.value = true
            _diagnosticResult.value = null
            val result = repository.runDiagnostics(testUrl, testKey)
            _diagnosticResult.value = result
            _isTestingConnection.value = false
        }
    }
}
