package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.config.EliteHubConfig
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.RubyRed
import com.example.viewmodel.EliteHubViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublishScreen(
    viewModel: EliteHubViewModel,
    onNavigateBack: () -> Unit,
    onPublishedSuccess: (String) -> Unit
) {
    val context = LocalContext.current
    val savedProfile by viewModel.profileName.collectAsStateWithLifecycle()
    val savedEmail by viewModel.userEmail.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    var scriptName by remember { mutableStateOf("") }
    var selectedLanguage by remember { mutableStateOf("lua") }
    var sourceCode by remember { mutableStateOf("-- EliteHub Script\nprint(\"Hello from EliteHub!\")\n") }
    var profileName by remember(savedProfile) { mutableStateOf(savedProfile) }
    var email by remember(savedEmail) { mutableStateOf(savedEmail) }

    var formError by remember { mutableStateOf<String?>(null) }

    val byteCount = remember(sourceCode) { sourceCode.toByteArray(Charsets.UTF_8).size }
    val isOverLimit = byteCount > EliteHubConfig.MAX_SOURCE_BYTES

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Publish, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PUBLISH SCRIPT",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Script Name Input
            OutlinedTextField(
                value = scriptName,
                onValueChange = {
                    scriptName = it
                    formError = null
                },
                label = { Text("Script Name") },
                placeholder = { Text("e.g. speed_booster_v2") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("publish_name_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedIndicatorColor = CyanNeon
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Language Selector Chips
            Text(
                text = "TARGET LANGUAGE",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EliteHubConfig.ALLOWED_LANGUAGES.forEach { lang ->
                    FilterChip(
                        selected = (selectedLanguage == lang),
                        onClick = { selectedLanguage = lang },
                        label = { Text(lang.uppercase()) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Author Profile & Email
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = profileName,
                    onValueChange = {
                        profileName = it
                        formError = null
                    },
                    label = { Text("Creator Profile") },
                    placeholder = { Text("Your username") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("publish_profile_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        formError = null
                    },
                    label = { Text("Owner Email") },
                    placeholder = { Text("owner@domain.com") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("publish_email_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Code Source Header & Quick Syntax Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SOURCE CODE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${byteCount} / 1,048,576 bytes",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = if (isOverLimit) RubyRed else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Quick Code Snippets Insertion Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val snippets = when (selectedLanguage) {
                    "lua" -> listOf("function ()", "local x =", "if true then", "end", "print()")
                    "py" -> listOf("def func():", "if __name__ == '__main__':", "import os", "print()")
                    "js" -> listOf("const fn = () => {", "console.log()", "export default", "async function")
                    else -> listOf("local", "function", "{ }", "[ ]", "( )")
                }
                snippets.forEach { snippet ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        onClick = { sourceCode += "\n$snippet" }
                    ) {
                        Text(
                            text = snippet,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = CyanNeon
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Source Code Text Field
            OutlinedTextField(
                value = sourceCode,
                onValueChange = {
                    sourceCode = it
                    formError = null
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .testTag("publish_source_input"),
                textStyle = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedIndicatorColor = CyanNeon
                )
            )

            if (!formError.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = formError!!,
                    color = RubyRed,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Submit Button
            Button(
                onClick = {
                    // Validations
                    if (!EliteHubConfig.isValidScriptName(scriptName)) {
                        formError = "Invalid script name. Use 1-60 alphanumeric characters, dots, underscores, or hyphens."
                        return@Button
                    }
                    if (!EliteHubConfig.isValidProfileName(profileName)) {
                        formError = "Creator profile must be 1-40 alphanumeric characters, dots, underscores, or hyphens."
                        return@Button
                    }
                    if (email.isBlank() || !email.contains("@")) {
                        formError = "A valid email address is required for ownership."
                        return@Button
                    }
                    if (sourceCode.isBlank()) {
                        formError = "Script source code cannot be empty."
                        return@Button
                    }
                    if (isOverLimit) {
                        formError = "Source exceeds maximum 1 MiB limit."
                        return@Button
                    }

                    // Save profile locally
                    viewModel.saveProfile(profileName, email)

                    // Execute publish
                    viewModel.publishScript(
                        name = scriptName.trim(),
                        language = selectedLanguage.trim(),
                        source = sourceCode,
                        email = email.trim(),
                        profile = profileName.trim()
                    ) { success, message ->
                        if (success) {
                            Toast.makeText(context, "Published successfully!", Toast.LENGTH_LONG).show()
                            onPublishedSuccess(scriptName)
                        } else {
                            formError = message
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_submit_publish"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanNeon,
                    contentColor = Color(0xFF002229)
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color(0xFF002229), modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Default.Publish, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Publish to EliteHub", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
