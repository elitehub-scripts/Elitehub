package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.config.EliteHubConfig
import com.example.data.model.ScriptDto
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.LanguageBadge
import com.example.ui.components.ScriptCard
import com.example.ui.theme.CyanNeon
import com.example.viewmodel.EliteHubViewModel
import com.example.viewmodel.SortOption

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen(
    viewModel: EliteHubViewModel,
    onNavigateToDetail: (String) -> Unit,
    onNavigateToEdit: (String) -> Unit
) {
    val rawScripts by viewModel.rawScripts.collectAsStateWithLifecycle()
    val filteredScripts by viewModel.filteredScripts.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguageFilter.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()

    var showSortMenu by remember { mutableStateOf(false) }
    var scriptToDelete by remember { mutableStateOf<ScriptDto?>(null) }

    if (scriptToDelete != null) {
        val email by viewModel.userEmail.collectAsStateWithLifecycle()
        DeleteConfirmDialog(
            scriptName = scriptToDelete!!.name,
            onConfirm = {
                val target = scriptToDelete!!
                scriptToDelete = null
                viewModel.deleteScript(target.name, email) { _, _ -> }
            },
            onDismiss = { scriptToDelete = null }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DISCOVER",
                            style = MaterialTheme.typography.titleLarge,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Default.Sort, contentDescription = "Sort options")
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Newest Updated") },
                                onClick = {
                                    viewModel.setSortOption(SortOption.NEWEST)
                                    showSortMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Name (A-Z)") },
                                onClick = {
                                    viewModel.setSortOption(SortOption.NAME_ASC)
                                    showSortMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Size (Largest)") },
                                onClick = {
                                    viewModel.setSortOption(SortOption.SIZE_DESC)
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Category Cards
            item {
                Text(
                    text = "CATEGORIES & ENVIRONMENTS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(EliteHubConfig.ALLOWED_LANGUAGES) { lang ->
                        val count = rawScripts.count { it.language.equals(lang, ignoreCase = true) }
                        val isSelected = selectedLanguage.equals(lang, ignoreCase = true)

                        OutlinedCard(
                            onClick = {
                                if (isSelected) viewModel.setLanguageFilter(null)
                                else viewModel.setLanguageFilter(lang)
                            },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(
                                if (isSelected) 2.dp else 1.dp,
                                if (isSelected) CyanNeon else MaterialTheme.colorScheme.outline
                            ),
                            colors = CardDefaults.outlinedCardColors(
                                containerColor = if (isSelected) CyanNeon.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.width(115.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                LanguageBadge(language = lang)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "$count scripts",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Current Filter & Sort state summary
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (selectedLanguage != null) "SHOWING: ${selectedLanguage!!.uppercase()}" else "ALL SCRIPTS (${filteredScripts.size})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Text(
                        text = when (sortOption) {
                            SortOption.NEWEST -> "Sorted: Newest"
                            SortOption.NAME_ASC -> "Sorted: A-Z"
                            SortOption.SIZE_DESC -> "Sorted: Size"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = CyanNeon
                    )
                }
            }

            // Script list
            if (filteredScripts.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No scripts match the selected filter.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(filteredScripts, key = { it.name }) { script ->
                    val isFav = favorites.contains(script.name)
                    ScriptCard(
                        script = script,
                        isFavorite = isFav,
                        onCardClick = { onNavigateToDetail(script.name) },
                        onToggleFavorite = { viewModel.toggleFavorite(script.name) },
                        onEditClick = if (script.owned) { { onNavigateToEdit(script.name) } } else null,
                        onDeleteClick = if (script.owned) { { scriptToDelete = script } } else null
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}
