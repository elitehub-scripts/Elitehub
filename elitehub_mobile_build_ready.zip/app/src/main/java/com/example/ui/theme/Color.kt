package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Accents
val CyanNeon = Color(0xFF00E5FF)
val CyanNeonDark = Color(0xFF00B4D8)
val CyanGlow = Color(0xFF18FFFF)
val VioletNeon = Color(0xFFA855F7)
val EmeraldGreen = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RubyRed = Color(0xFFEF4444)

// Language Badges
val LangLua = Color(0xFF00599C)
val LangEls = Color(0xFF8B5CF6)
val LangPython = Color(0xFF3776AB)
val LangJs = Color(0xFFF7DF1E)
val LangJson = Color(0xFF10B981)
val LangTxt = Color(0xFF94A3B8)

// Dark Theme Surfaces
val BackgroundDark = Color(0xFF090D14)
val SurfaceDark = Color(0xFF111723)
val SurfaceElevatedDark = Color(0xFF182234)
val SurfaceBorderDark = Color(0xFF24334C)
val SurfaceHighlightDark = Color(0xFF1E2B42)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Code Viewer Dark Palette
val CodeBackground = Color(0xFF070B10)
val CodeGutter = Color(0xFF111722)
val CodeGutterText = Color(0xFF475569)
val CodeText = Color(0xFFE2E8F0)
val CodeKeyword = Color(0xFFFF7B72)
val CodeFunction = Color(0xFF79C0FF)
val CodeString = Color(0xFFA5D6FF)
val CodeComment = Color(0xFF8B949E)

// Light Theme Fallbacks
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceBorderLight = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
