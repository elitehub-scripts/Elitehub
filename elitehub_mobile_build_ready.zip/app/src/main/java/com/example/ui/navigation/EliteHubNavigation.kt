package com.example.ui.navigation

import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.ConnectionDiagnosticScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.PublishScreen
import com.example.ui.screens.ScriptDetailScreen
import com.example.ui.screens.ScriptEditorScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.CyanNeon
import com.example.viewmodel.EliteHubViewModel

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val DISCOVER = "discover"
    const val CREATE = "create"
    const val LIBRARY = "library"
    const val PROFILE = "profile"
    const val SEARCH = "search"
    const val SCRIPT_DETAIL = "detail/{name}"
    const val SCRIPT_EDITOR = "editor/{name}"
    const val DIAGNOSTICS = "diagnostics"
    const val SETTINGS = "settings"
    const val ABOUT = "about"

    fun detail(name: String): String = "detail/${Uri.encode(name)}"
    fun editor(name: String): String = "editor/${Uri.encode(name)}"
}

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    object Home : BottomNavItem(Routes.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home")
    object Discover : BottomNavItem(Routes.DISCOVER, "Discover", Icons.Filled.Explore, Icons.Outlined.Explore, "nav_discover")
    object Create : BottomNavItem(Routes.CREATE, "Create", Icons.Filled.AddCircle, Icons.Filled.AddCircle, "nav_create")
    object Library : BottomNavItem(Routes.LIBRARY, "Library", Icons.Filled.Bookmark, Icons.Filled.BookmarkBorder, "nav_library")
    object Profile : BottomNavItem(Routes.PROFILE, "Profile", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
}

@Composable
fun EliteHubApp(
    viewModel: EliteHubViewModel
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = listOf(
        BottomNavItem.Home,
        BottomNavItem.Discover,
        BottomNavItem.Create,
        BottomNavItem.Library,
        BottomNavItem.Profile
    )

    val showBottomBar = currentRoute in listOf(
        Routes.HOME,
        Routes.DISCOVER,
        Routes.CREATE,
        Routes.LIBRARY,
        Routes.PROFILE
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.navigationBarsPadding(),
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    bottomNavItems.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = { Text(text = item.title, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CyanNeon,
                                selectedTextColor = CyanNeon,
                                indicatorColor = CyanNeon.copy(alpha = 0.15f),
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Routes.SPLASH
            ) {
                composable(Routes.SPLASH) {
                    SplashScreen(
                        onSplashFinished = {
                            navController.navigate(Routes.HOME) {
                                popUpTo(Routes.SPLASH) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Routes.HOME) {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { name -> navController.navigate(Routes.detail(name)) },
                        onNavigateToEdit = { name -> navController.navigate(Routes.editor(name)) },
                        onNavigateToPublish = { navController.navigate(Routes.CREATE) },
                        onNavigateToSearch = { navController.navigate(Routes.SEARCH) }
                    )
                }

                composable(Routes.DISCOVER) {
                    DiscoverScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { name -> navController.navigate(Routes.detail(name)) },
                        onNavigateToEdit = { name -> navController.navigate(Routes.editor(name)) }
                    )
                }

                composable(Routes.CREATE) {
                    PublishScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onPublishedSuccess = { name ->
                            navController.navigate(Routes.detail(name)) {
                                popUpTo(Routes.HOME) { inclusive = false }
                            }
                        }
                    )
                }

                composable(Routes.LIBRARY) {
                    LibraryScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { name -> navController.navigate(Routes.detail(name)) },
                        onNavigateToEdit = { name -> navController.navigate(Routes.editor(name)) },
                        onNavigateToPublish = { navController.navigate(Routes.CREATE) }
                    )
                }

                composable(Routes.PROFILE) {
                    ProfileScreen(
                        viewModel = viewModel,
                        onNavigateToDiagnostics = { navController.navigate(Routes.DIAGNOSTICS) },
                        onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                        onNavigateToAbout = { navController.navigate(Routes.ABOUT) }
                    )
                }

                composable(Routes.SEARCH) {
                    SearchScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onNavigateToDetail = { name -> navController.navigate(Routes.detail(name)) },
                        onNavigateToEdit = { name -> navController.navigate(Routes.editor(name)) }
                    )
                }

                composable(
                    route = Routes.SCRIPT_DETAIL,
                    arguments = listOf(navArgument("name") { type = NavType.StringType })
                ) { backStackEntry ->
                    val name = backStackEntry.arguments?.getString("name").orEmpty()
                    val decodedName = Uri.decode(name)
                    ScriptDetailScreen(
                        scriptName = decodedName,
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onNavigateToEdit = { editTarget -> navController.navigate(Routes.editor(editTarget)) }
                    )
                }

                composable(
                    route = Routes.SCRIPT_EDITOR,
                    arguments = listOf(navArgument("name") { type = NavType.StringType })
                ) { backStackEntry ->
                    val name = backStackEntry.arguments?.getString("name").orEmpty()
                    val decodedName = Uri.decode(name)
                    ScriptEditorScreen(
                        originalScriptName = decodedName,
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onSavedSuccess = { savedTarget ->
                            navController.navigate(Routes.detail(savedTarget)) {
                                popUpTo(Routes.HOME) { inclusive = false }
                            }
                        }
                    )
                }

                composable(Routes.DIAGNOSTICS) {
                    ConnectionDiagnosticScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() },
                        onNavigateToDiagnostics = { navController.navigate(Routes.DIAGNOSTICS) }
                    )
                }

                composable(Routes.ABOUT) {
                    AboutScreen(
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
