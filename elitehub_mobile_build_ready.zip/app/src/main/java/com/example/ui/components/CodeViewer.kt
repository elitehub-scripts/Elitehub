package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WrapText
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBackground
import com.example.ui.theme.CodeGutter
import com.example.ui.theme.CodeGutterText
import com.example.ui.theme.CodeText
import com.example.ui.theme.CyanNeon
import kotlinx.coroutines.launch

@Composable
fun CodeViewer(
    sourceCode: String,
    fontSizeSp: Int = 13,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()

    var isSearchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var isWrapText by remember { mutableStateOf(false) }

    val lines = remember(sourceCode) {
        if (sourceCode.isEmpty()) listOf("") else sourceCode.lines()
    }

    // Matching lines indices
    val matchingIndices = remember(lines, searchQuery) {
        if (searchQuery.isBlank()) emptyList()
        else lines.mapIndexedNotNull { index, line ->
            if (line.contains(searchQuery, ignoreCase = true)) index else null
        }
    }
    var currentMatchIndex by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CodeBackground, RoundedCornerShape(12.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
    ) {
        // Code Viewer Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CodeGutter, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${lines.size} lines • ${sourceCode.toByteArray(Charsets.UTF_8).size} bytes",
                style = MaterialTheme.typography.bodySmall,
                color = CodeGutterText,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Search in code toggle
                IconButton(
                    onClick = {
                        isSearchVisible = !isSearchVisible
                        if (!isSearchVisible) searchQuery = ""
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search in code",
                        tint = if (isSearchVisible) CyanNeon else CodeGutterText,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Wrap Text toggle
                IconButton(
                    onClick = { isWrapText = !isWrapText },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WrapText,
                        contentDescription = "Toggle line wrap",
                        tint = if (isWrapText) CyanNeon else CodeGutterText,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Copy Code
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("EliteHub Code", sourceCode))
                        Toast.makeText(context, "Full source code copied!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(32.dp).testTag("btn_copy_code")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        tint = CodeGutterText,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Search Bar within Code
        if (isSearchVisible) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        currentMatchIndex = 0
                    },
                    placeholder = { Text("Find in code...", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("code_search_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = CyanNeon
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = if (matchingIndices.isEmpty()) "0/0" else "${currentMatchIndex + 1}/${matchingIndices.size}",
                    fontSize = 11.sp,
                    color = CodeGutterText,
                    fontFamily = FontFamily.Monospace
                )

                IconButton(
                    onClick = {
                        if (matchingIndices.isNotEmpty()) {
                            currentMatchIndex = (currentMatchIndex - 1 + matchingIndices.size) % matchingIndices.size
                            scope.launch {
                                listState.animateScrollToItem(matchingIndices[currentMatchIndex])
                            }
                        }
                    },
                    enabled = matchingIndices.isNotEmpty(),
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match", tint = CodeGutterText)
                }

                IconButton(
                    onClick = {
                        if (matchingIndices.isNotEmpty()) {
                            currentMatchIndex = (currentMatchIndex + 1) % matchingIndices.size
                            scope.launch {
                                listState.animateScrollToItem(matchingIndices[currentMatchIndex])
                            }
                        }
                    },
                    enabled = matchingIndices.isNotEmpty(),
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match", tint = CodeGutterText)
                }

                IconButton(
                    onClick = {
                        isSearchVisible = false
                        searchQuery = ""
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close search", tint = CodeGutterText)
                }
            }
        }

        // Code Area
        val codeModifier = if (isWrapText) Modifier.fillMaxWidth() else Modifier.horizontalScroll(horizontalScrollState)

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 4.dp)
        ) {
            itemsIndexed(lines) { index, lineText ->
                val lineNumber = index + 1
                val isCurrentMatch = matchingIndices.getOrNull(currentMatchIndex) == index

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (isCurrentMatch) Modifier.background(CyanNeon.copy(alpha = 0.15f))
                            else Modifier
                        )
                ) {
                    // Line number gutter
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .background(CodeGutter)
                            .padding(end = 8.dp, top = 2.dp, bottom = 2.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Text(
                            text = lineNumber.toString(),
                            color = CodeGutterText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = fontSizeSp.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Line content with highlight
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 2.dp)
                            .then(codeModifier)
                    ) {
                        val annotated = remember(lineText, searchQuery) {
                            buildAnnotatedString {
                                if (searchQuery.isNotBlank() && lineText.contains(searchQuery, ignoreCase = true)) {
                                    var startIndex = 0
                                    val lowerText = lineText.lowercase()
                                    val lowerQuery = searchQuery.lowercase()
                                    while (startIndex < lineText.length) {
                                        val matchIndex = lowerText.indexOf(lowerQuery, startIndex)
                                        if (matchIndex == -1) {
                                            append(lineText.substring(startIndex))
                                            break
                                        }
                                        append(lineText.substring(startIndex, matchIndex))
                                        withStyle(SpanStyle(background = Color(0xFFEAB308).copy(alpha = 0.4f), color = Color.White)) {
                                            append(lineText.substring(matchIndex, matchIndex + searchQuery.length))
                                        }
                                        startIndex = matchIndex + searchQuery.length
                                    }
                                } else {
                                    append(lineText)
                                }
                            }
                        }

                        Text(
                            text = annotated,
                            color = CodeText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = fontSizeSp.sp,
                            softWrap = isWrapText
                        )
                    }
                }
            }
        }
    }
}
