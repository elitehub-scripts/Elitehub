package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LangEls
import com.example.ui.theme.LangJs
import com.example.ui.theme.LangJson
import com.example.ui.theme.LangLua
import com.example.ui.theme.LangPython
import com.example.ui.theme.LangTxt

@Composable
fun LanguageBadge(
    language: String,
    modifier: Modifier = Modifier
) {
    val langLower = language.lowercase().trim()
    val (bgColor, textColor) = when (langLower) {
        "lua" -> Pair(LangLua.copy(alpha = 0.22f), LangLua)
        "els" -> Pair(LangEls.copy(alpha = 0.22f), LangEls)
        "py" -> Pair(LangPython.copy(alpha = 0.22f), Color(0xFF60A5FA))
        "js" -> Pair(LangJs.copy(alpha = 0.22f), Color(0xFFFACC15))
        "json" -> Pair(LangJson.copy(alpha = 0.22f), LangJson)
        else -> Pair(LangTxt.copy(alpha = 0.22f), LangTxt)
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(
            text = language.uppercase(),
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}
