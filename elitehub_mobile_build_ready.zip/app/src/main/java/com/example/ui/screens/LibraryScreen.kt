package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ScriptDto
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.ScriptCard
import com.example.ui.theme.CyanNeon
import com.example.viewmodel.EliteHubViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: EliteHubViewModel,
    onNavigateToDetail: (String) -> Unit,
    onNavigateToEdit: (String) -> Unit,
    onNavigateToPublish: () -> Unit
) {
    val myScripts by viewModel.myScripts.collectAsStateWithLifecycle()
    val rawScripts by viewModel.rawScripts.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val userEmail by viewModel.userEmail.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var scriptToDelete by remember { mutableStateOf<ScriptDto?>(null) }

    val favoriteScripts = remember(rawScripts, favorites) {
        rawScripts.filter { favorites.contains(it.name) }
    }

    val historyScripts = remember(rawScripts, history) {
        history.mapNotNull { histName ->
            rawScripts.find { it.name.equals(histName, ignoreCase = true) }
        }
    }

    if (scriptToDelete != null) {
        DeleteConfirmDialog(
            scriptName = scriptToDelete!!.name,
            onConfirm = {
                val target = scriptToDelete!!
                scriptToDelete = null
                viewModel.deleteScript(target.name, userEmail) { _, _ -> }
            },
            onDismiss = { scriptToDelete = null }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bookmark, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LIBRARY",
                            style = MaterialTheme.typography.titleLarge,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    if (selectedTabIndex == 2 && historyScripts.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearHistory() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear history", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Tab Row
            PrimaryTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CyanNeon
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("My Scripts (${myScripts.size})") },
                    modifier = Modifier.testTag("tab_my_scripts")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("Favorites (${favoriteScripts.size})") },
                    modifier = Modifier.testTag("tab_favorites")
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = { Text("History (${historyScripts.size})") },
                    modifier = Modifier.testTag("tab_history")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (selectedTabIndex) {
                0 -> {
                    // My Scripts
                    if (myScripts.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Default.Code,
                            title = "No owned scripts yet",
                            subtitle = "Publish a script to have it saved under your creator profile and email.",
                            actionLabel = "Publish Now",
                            onAction = onNavigateToPublish
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(myScripts, key = { it.name }) { script ->
                                ScriptCard(
                                    script = script,
                                    isFavorite = favorites.contains(script.name),
                                    onCardClick = { onNavigateToDetail(script.name) },
                                    onToggleFavorite = { viewModel.toggleFavorite(script.name) },
                                    onEditClick = { onNavigateToEdit(script.name) },
                                    onDeleteClick = { scriptToDelete = script }
                                )
                            }
                            item { Spacer(modifier = Modifier.height(60.dp)) }
                        }
                    }
                }
                1 -> {
                    // Favorites
                    if (favoriteScripts.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Default.Bookmark,
                            title = "No favorites saved",
                            subtitle = "Bookmark your favorite scripts to access their code anytime.",
                            actionLabel = null,
                            onAction = null
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(favoriteScripts, key = { it.name }) { script ->
                                ScriptCard(
                                    script = script,
                                    isFavorite = true,
                                    onCardClick = { onNavigateToDetail(script.name) },
                                    onToggleFavorite = { viewModel.toggleFavorite(script.name) },
                                    onEditClick = if (script.owned) { { onNavigateToEdit(script.name) } } else null,
                                    onDeleteClick = if (script.owned) { { scriptToDelete = script } } else null
                                )
                            }
                            item { Spacer(modifier = Modifier.height(60.dp)) }
                        }
                    }
                }
                2 -> {
                    // History
                    if (historyScripts.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Default.History,
                            title = "No recent history",
                            subtitle = "Scripts you view in EliteHub will appear here for fast access.",
                            actionLabel = null,
                            onAction = null
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(historyScripts, key = { it.name }) { script ->
                                ScriptCard(
                                    script = script,
                                    isFavorite = favorites.contains(script.name),
                                    onCardClick = { onNavigateToDetail(script.name) },
                                    onToggleFavorite = { viewModel.toggleFavorite(script.name) },
                                    onEditClick = if (script.owned) { { onNavigateToEdit(script.name) } } else null,
                                    onDeleteClick = if (script.owned) { { scriptToDelete = script } } else null
                                )
                            }
                            item { Spacer(modifier = Modifier.height(60.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyLibraryState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String?,
    onAction: (() -> Unit)?
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(20.dp))
                Button(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}
