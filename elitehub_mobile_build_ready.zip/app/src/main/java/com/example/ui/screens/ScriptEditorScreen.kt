package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.config.EliteHubConfig
import com.example.data.model.ScriptDto
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.RubyRed
import com.example.viewmodel.EliteHubViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptEditorScreen(
    originalScriptName: String,
    viewModel: EliteHubViewModel,
    onNavigateBack: () -> Unit,
    onSavedSuccess: (String) -> Unit
) {
    val context = LocalContext.current
    val rawScripts by viewModel.rawScripts.collectAsStateWithLifecycle()
    val userEmail by viewModel.userEmail.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    val script = remember(rawScripts, originalScriptName) {
        rawScripts.find { it.name.equals(originalScriptName, ignoreCase = true) }
            ?: ScriptDto(name = originalScriptName, language = "txt")
    }

    var newName by remember { mutableStateOf(script.name) }
    var selectedLanguage by remember { mutableStateOf(script.language) }
    var sourceCode by remember { mutableStateOf("") }
    var isFetchingSource by remember { mutableStateOf(true) }
    var formError by remember { mutableStateOf<String?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val byteCount = remember(sourceCode) { sourceCode.toByteArray(Charsets.UTF_8).size }
    val isOverLimit = byteCount > EliteHubConfig.MAX_SOURCE_BYTES

    LaunchedEffect(originalScriptName) {
        isFetchingSource = true
        viewModel.loadScriptSource(script) { loadedSource, _ ->
            sourceCode = loadedSource ?: ""
            isFetchingSource = false
        }
    }

    if (showDeleteDialog) {
        DeleteConfirmDialog(
            scriptName = originalScriptName,
            onConfirm = {
                showDeleteDialog = false
                viewModel.deleteScript(originalScriptName, userEmail) { success, _ ->
                    if (success) {
                        Toast.makeText(context, "Script deleted", Toast.LENGTH_SHORT).show()
                        onNavigateBack()
                    }
                }
            },
            onDismiss = { showDeleteDialog = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Column {
                        Text(
                            text = "EDIT SCRIPT",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Original: $originalScriptName",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete script", tint = RubyRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (isFetchingSource) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = CyanNeon)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Script Name (Allows renaming while preserving original_name)
                OutlinedTextField(
                    value = newName,
                    onValueChange = {
                        newName = it
                        formError = null
                    },
                    label = { Text("Script Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_name_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = CyanNeon
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Language
                Text(
                    text = "TARGET LANGUAGE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EliteHubConfig.ALLOWED_LANGUAGES.forEach { lang ->
                        FilterChip(
                            selected = (selectedLanguage.equals(lang, ignoreCase = true)),
                            onClick = { selectedLanguage = lang },
                            label = { Text(lang.uppercase()) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Code Source Header & Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SOURCE CODE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "$byteCount / 1,048,576 bytes",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (isOverLimit) RubyRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Editor Text Field
                OutlinedTextField(
                    value = sourceCode,
                    onValueChange = {
                        sourceCode = it
                        formError = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                        .testTag("editor_source_input"),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    ),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = CyanNeon
                    )
                )

                if (!formError.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = formError!!,
                        color = RubyRed,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Save Changes Button
                Button(
                    onClick = {
                        if (!EliteHubConfig.isValidScriptName(newName)) {
                            formError = "Invalid script name."
                            return@Button
                        }
                        if (userEmail.isBlank()) {
                            formError = "Owner email not set. Please set your owner email in Profile."
                            return@Button
                        }
                        if (isOverLimit) {
                            formError = "Source exceeds maximum 1 MiB limit."
                            return@Button
                        }

                        viewModel.saveScript(
                            name = newName.trim(),
                            originalName = originalScriptName.trim(),
                            language = selectedLanguage.trim(),
                            source = sourceCode,
                            email = userEmail.trim()
                        ) { success, message ->
                            if (success) {
                                Toast.makeText(context, "Saved changes!", Toast.LENGTH_SHORT).show()
                                onSavedSuccess(newName)
                            } else {
                                formError = message
                            }
                        }
                    },
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_save_changes"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanNeon,
                        contentColor = Color(0xFF002229)
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color(0xFF002229), modifier = Modifier.size(20.dp))
                    } else {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Changes", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
