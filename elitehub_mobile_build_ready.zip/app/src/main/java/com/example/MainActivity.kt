package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.navigation.EliteHubApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.EliteHubViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: EliteHubViewModel = viewModel()
            val themeMode = viewModel.themeMode.collectAsStateWithLifecycle().value

            val isDark = when (themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme() || true // Dark-first default for developer tool vibe
            }

            MyApplicationTheme(darkTheme = isDark) {
                EliteHubApp(viewModel = viewModel)
            }
        }
    }
}
