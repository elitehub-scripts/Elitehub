package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.config.EliteHubConfig
import com.example.data.model.ScriptDto
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app_name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ELITEHUB", appName)
  }

  @Test
  fun `verify EliteHubConfig validation rules`() {
    assertTrue(EliteHubConfig.isValidScriptName("my_script_v1"))
    assertTrue(EliteHubConfig.isValidScriptName("auto-farm.lua"))
    assertFalse(EliteHubConfig.isValidScriptName(""))
    assertFalse(EliteHubConfig.isValidScriptName("invalid script with spaces"))

    assertTrue(EliteHubConfig.isValidProfileName("Dev_Elite 99"))
    assertFalse(EliteHubConfig.isValidProfileName(""))
    assertFalse(EliteHubConfig.isValidProfileName("invalid!profile#name"))

    assertTrue(EliteHubConfig.isAllowedLanguage("lua"))
    assertTrue(EliteHubConfig.isAllowedLanguage("ELS"))
    assertTrue(EliteHubConfig.isAllowedLanguage("py"))
    assertFalse(EliteHubConfig.isAllowedLanguage("cpp"))
    assertFalse(EliteHubConfig.isAllowedLanguage("ruby"))
  }

  @Test
  fun `verify ScriptDto formatted size calculation`() {
    val small = ScriptDto(name = "small", bytes = 500)
    assertEquals("500 B", small.getFormattedSize())

    val medium = ScriptDto(name = "medium", bytes = 2048)
    assertEquals("2.0 KB", medium.getFormattedSize())
  }

  @Test
  fun `verify EliteHub locked domain and key`() {
    assertEquals("https://elitehub.unaux.com/", EliteHubConfig.LOCKED_BASE_URL)
    assertEquals("NILKxgj_us22aBOUb3Ahd-kUldNgE0VOdOGwDTtyFor2aI", EliteHubConfig.LOCKED_APP_KEY)
  }
}
